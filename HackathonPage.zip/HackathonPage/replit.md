# Overview

This is a full-stack web application built with React, Express, and PostgreSQL. The project follows a modern TypeScript-first architecture with a monorepo structure containing both client and server code. The application appears to be designed for event registration or hackathon management, featuring a comprehensive UI component system built with shadcn/ui and Radix UI primitives.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for build tooling
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming and a dark-mode design system
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation resolvers

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Schema Validation**: Zod for runtime type validation
- **Development**: Hot reload with tsx for TypeScript execution

## Database Design
- **Database**: PostgreSQL with Neon serverless driver
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Current Schema**: Users table with id, username, and password fields
- **Type Safety**: Full TypeScript integration with inferred types from schema

## Project Structure
- **Monorepo Layout**: Shared code in `/shared`, client in `/client`, server in `/server`
- **Shared Types**: Database schemas and validation rules shared between client and server
- **Build Process**: Separate build processes for client (Vite) and server (esbuild)

## Development Tools
- **Hot Reload**: Vite dev server with HMR for frontend, tsx for backend
- **Type Checking**: Strict TypeScript configuration across the entire codebase
- **Path Aliases**: Configured aliases for clean imports (@/, @shared/, @assets/)
- **Replit Integration**: Custom plugins for Replit development environment

## Authentication & Storage
- **Storage Interface**: Abstracted storage layer with memory-based implementation for development
- **Session Management**: Connect-pg-simple for PostgreSQL session storage
- **User Management**: Basic user creation and retrieval functionality

# External Dependencies

## Database
- **Neon PostgreSQL**: Serverless PostgreSQL database with connection pooling
- **Connection**: Uses DATABASE_URL environment variable for database connectivity

## UI Libraries
- **Radix UI**: Comprehensive set of accessible, unstyled UI primitives
- **Lucide React**: Icon library for consistent iconography
- **Embla Carousel**: Touch-friendly carousel component
- **Vaul**: Drawer/sheet component library

## Build & Development
- **Vite**: Frontend build tool with React plugin
- **esbuild**: Backend bundling for production builds
- **PostCSS**: CSS processing with Tailwind CSS and Autoprefixer

## Validation & Forms
- **Zod**: Schema validation library for runtime type checking
- **React Hook Form**: Form library with validation integration
- **Drizzle Zod**: Integration between Drizzle ORM and Zod validation

## Utilities
- **clsx & tailwind-merge**: Utility for conditional CSS class composition
- **date-fns**: Date manipulation and formatting library
- **nanoid**: URL-safe unique ID generator
- **class-variance-authority**: Utility for creating component variants