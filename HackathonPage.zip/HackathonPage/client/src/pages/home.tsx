import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { 
  Code, 
  Calendar, 
  Clock, 
  MapPin, 
  Rocket, 
  Info, 
  Trophy, 
  Users, 
  Network, 
  University, 
  Mail, 
  Phone, 
  ChevronDown, 
  NotebookPen, 
  Twitter,
  Instagram,
  Linkedin,
  Github
} from "lucide-react";

export default function Home() {
  const { toast } = useToast();
  const [openFAQ, setOpenFAQ] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    institution: "",
    experience: "",
    teamName: ""
  });

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const toggleFAQ = (index: number) => {
    setOpenFAQ(openFAQ === index ? null : index);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleRegistration = () => {
    scrollToSection("contact");
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.firstName || !formData.lastName || !formData.email || !formData.phone) {
      toast({
        title: "Error",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }

    // Simulate form submission
    toast({
      title: "Registration Successful!",
      description: "Thank you for registering for HackVerse 2025. We'll contact you soon with further details."
    });
    
    // Reset form
    setFormData({
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      institution: "",
      experience: "",
      teamName: ""
    });
  };

  const scheduleItems = [
    {
      title: "Registration & Welcome",
      time: "9:00 AM - 10:00 AM",
      description: "Check-in, team formation, welcome address, and problem statement reveal."
    },
    {
      title: "Hackathon Kickoff",
      time: "10:00 AM - 10:30 AM",
      description: "Opening ceremony, rules explanation, and official start of the coding challenge."
    },
    {
      title: "Development Phase 1",
      time: "10:30 AM - 1:00 PM",
      description: "Intensive coding session with mentor support and technical guidance available."
    },
    {
      title: "Lunch Break",
      time: "1:00 PM - 2:00 PM",
      description: "Networking lunch with fellow participants and mentors."
    },
    {
      title: "Development Phase 2",
      time: "2:00 PM - 5:00 PM",
      description: "Continue development, implement features, and prepare for final submissions."
    },
    {
      title: "Final Presentations",
      time: "5:00 PM - 6:30 PM",
      description: "Teams present their solutions to judges and fellow participants."
    },
    {
      title: "Awards Ceremony",
      time: "6:30 PM - 7:00 PM",
      description: "Winner announcement, prize distribution, and closing remarks."
    }
  ];

  const faqItems = [
    {
      question: "Who can participate in HackVerse 2025?",
      answer: "HackVerse 2025 is open to all students, professionals, and tech enthusiasts. You can participate individually or in teams of up to 3 members."
    },
    {
      question: "What should I bring to the hackathon?",
      answer: "Bring your laptop, chargers, any development tools you prefer, and your creative mindset. We'll provide WiFi, workspace, meals, and refreshments."
    },
    {
      question: "What are the participation fees?",
      answer: "Individual participation: ₹499 | Team of 3 members: ₹999. This covers venue, meals, refreshments, and event materials for the entire 8-hour hackathon."
    },
    {
      question: "What are the judging criteria?",
      answer: "Projects will be judged based on innovation, technical implementation, design, feasibility, and presentation quality."
    },
    {
      question: "What are the project submission requirements?",
      answer: "All projects must be ready and must have a PowerPoint presentation (PPT) and at least a 2-minute video with presentation about how to solve the problem."
    },
    {
      question: "Will there be mentors available?",
      answer: "Yes! We have 20+ experienced mentors from various tech domains who will be available throughout the event to guide and support teams."
    }
  ];


  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass-card border-b border-border" data-testid="navigation">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <Code className="text-2xl text-accent" />
              <span className="text-xl font-bold">HackVerse</span>
            </div>
            <div className="hidden md:flex space-x-8">
              <button onClick={() => scrollToSection("home")} className="hover:text-accent transition-colors" data-testid="nav-home">
                Home
              </button>
              <button onClick={() => scrollToSection("about")} className="hover:text-accent transition-colors" data-testid="nav-about">
                About
              </button>
              <button onClick={() => scrollToSection("schedule")} className="hover:text-accent transition-colors" data-testid="nav-schedule">
                Schedule
              </button>
              <button onClick={() => scrollToSection("faq")} className="hover:text-accent transition-colors" data-testid="nav-faq">
                FAQ
              </button>
              <button onClick={() => scrollToSection("contact")} className="hover:text-accent transition-colors" data-testid="nav-contact">
                Contact
              </button>
            </div>
            <Button onClick={handleRegistration} className="bg-accent hover:bg-accent/90 text-accent-foreground" data-testid="button-register-nav">
              Register Now
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden" data-testid="hero-section">
        <div className="absolute inset-0 gradient-bg hero-pattern"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent"></div>
        
        <div className="absolute inset-0 opacity-20">
          <img 
            src="https://images.unsplash.com/photo-1531482615713-2afd69097998?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080" 
            alt="Hackathon event with participants" 
            className="w-full h-full object-cover" 
          />
        </div>

        <div className="relative z-10 max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-black mb-6 bg-gradient-to-r from-white via-blue-100 to-cyan-100 bg-clip-text text-transparent" data-testid="title-main">
            HackVerse
            <span className="block text-3xl sm:text-4xl lg:text-5xl mt-2 text-accent">2025</span>
          </h1>
          <p className="text-xl sm:text-2xl mb-8 text-gray-200 max-w-2xl mx-auto" data-testid="text-subtitle">
            The Ultimate 8-Hour Coding Challenge at Chaudhary Ranbir Singh University, Jind
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8">
            <div className="flex items-center space-x-2 text-lg" data-testid="info-date">
              <Calendar className="text-accent" />
              <span>October 25, 2025</span>
            </div>
            <div className="flex items-center space-x-2 text-lg" data-testid="info-duration">
              <Clock className="text-accent" />
              <span>8 Hours</span>
            </div>
            <div className="flex items-center space-x-2 text-lg" data-testid="info-location">
              <MapPin className="text-accent" />
              <span>CRS University, Jind</span>
            </div>
          </div>
          <div className="mb-12">
            <div className="glass-card max-w-md mx-auto p-6 rounded-xl border border-white/20">
              <h3 className="text-xl font-bold mb-4 text-center text-white">Registration Fees</h3>
              <div className="space-y-3 text-center">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Individual:</span>
                  <span className="text-2xl font-bold text-accent">₹499</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Team (3 members):</span>
                  <span className="text-2xl font-bold text-accent">₹999</span>
                </div>
              </div>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={handleRegistration}
              className="bg-accent hover:bg-accent/90 text-accent-foreground px-8 py-4 text-lg font-semibold transition-all transform hover:scale-105"
              data-testid="button-register-hero"
            >
              <Rocket className="mr-2" />
              Register Now
            </Button>
            <Button 
              onClick={() => scrollToSection("schedule")}
              variant="outline"
              className="glass-card border border-white/20 hover:border-white/40 text-white px-8 py-4 text-lg font-semibold"
              data-testid="button-learn-more"
            >
              <Info className="mr-2" />
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-card" data-testid="about-section">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold mb-6" data-testid="title-about">About HackVerse 2025</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-about-subtitle">
              Join the most exciting 8-hour hackathon at Chaudhary Ranbir Singh University, where innovation meets competition
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <img 
                src="https://images.unsplash.com/photo-1461749280684-dccba630e2f6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Modern coding workspace" 
                className="rounded-2xl shadow-2xl" 
                data-testid="img-coding-workspace"
              />
            </div>
            <div className="space-y-6">
              <h3 className="text-3xl font-bold" data-testid="title-what-is">What is HackVerse?</h3>
              <p className="text-lg text-muted-foreground" data-testid="text-description">
                HackVerse 2025 is an intensive 8-hour hackathon designed to bring together the brightest minds in technology. 
                Participants will work in teams to develop innovative solutions to real-world problems.
              </p>
              <div className="grid grid-cols-2 gap-4">
                <Card className="glass-card text-center">
                  <CardContent className="p-4">
                    <div className="text-3xl font-bold text-accent" data-testid="stat-hours">8</div>
                    <div className="text-sm text-muted-foreground">Hours</div>
                  </CardContent>
                </Card>
                <Card className="glass-card text-center">
                  <CardContent className="p-4">
                    <div className="text-3xl font-bold text-accent" data-testid="stat-teams">50+</div>
                    <div className="text-sm text-muted-foreground">Teams</div>
                  </CardContent>
                </Card>
                <Card className="glass-card text-center">
                  <CardContent className="p-4">
                    <div className="text-3xl font-bold text-accent" data-testid="stat-prizes">₹1L+</div>
                    <div className="text-sm text-muted-foreground">Prizes</div>
                  </CardContent>
                </Card>
                <Card className="glass-card text-center">
                  <CardContent className="p-4">
                    <div className="text-3xl font-bold text-accent" data-testid="stat-mentors">20+</div>
                    <div className="text-sm text-muted-foreground">Mentors</div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="glass-card text-center">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-gradient-to-r from-accent to-orange-400 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Trophy className="text-2xl text-white" />
                </div>
                <h4 className="text-xl font-bold mb-4" data-testid="highlight-prizes-title">Exciting Prizes</h4>
                <p className="text-muted-foreground" data-testid="highlight-prizes-desc">
                  Win cash prizes, internship opportunities, and exclusive tech gadgets for the top performing teams.
                </p>
              </CardContent>
            </Card>
            
            <Card className="glass-card text-center">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-gradient-to-r from-primary to-blue-400 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Users className="text-2xl text-white" />
                </div>
                <h4 className="text-xl font-bold mb-4" data-testid="highlight-mentorship-title">Expert Mentorship</h4>
                <p className="text-muted-foreground" data-testid="highlight-mentorship-desc">
                  Get guidance from industry experts and experienced developers throughout the event.
                </p>
              </CardContent>
            </Card>
            
            <Card className="glass-card text-center">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-gradient-to-r from-secondary to-cyan-400 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Network className="text-2xl text-white" />
                </div>
                <h4 className="text-xl font-bold mb-4" data-testid="highlight-networking-title">Networking</h4>
                <p className="text-muted-foreground" data-testid="highlight-networking-desc">
                  Connect with like-minded developers, potential co-founders, and industry professionals.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Schedule Section */}
      <section id="schedule" className="py-20 bg-background" data-testid="schedule-section">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold mb-6" data-testid="title-schedule">Event Schedule</h2>
            <p className="text-xl text-muted-foreground" data-testid="text-schedule-subtitle">
              8 hours of intensive coding, learning, and innovation
            </p>
          </div>

          <div className="relative">
            <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gradient-to-b from-accent to-primary"></div>
            
            <div className="space-y-8">
              {scheduleItems.map((item, index) => (
                <div key={index} className="relative pl-16 timeline-item" data-testid={`timeline-item-${index}`}>
                  <Card className="glass-card">
                    <CardContent className="p-6">
                      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4">
                        <h3 className="text-xl font-bold" data-testid={`timeline-title-${index}`}>{item.title}</h3>
                        <span className="text-accent font-semibold" data-testid={`timeline-time-${index}`}>{item.time}</span>
                      </div>
                      <p className="text-muted-foreground" data-testid={`timeline-desc-${index}`}>{item.description}</p>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>


      {/* FAQ Section */}
      <section id="faq" className="py-20 bg-background" data-testid="faq-section">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold mb-6" data-testid="title-faq">Frequently Asked Questions</h2>
            <p className="text-xl text-muted-foreground" data-testid="text-faq-subtitle">
              Everything you need to know about HackVerse 2025
            </p>
          </div>

          <div className="space-y-4">
            {faqItems.map((faq, index) => (
              <Card key={index} className="glass-card overflow-hidden" data-testid={`faq-item-${index}`}>
                <button 
                  className="w-full p-6 text-left flex justify-between items-center hover:bg-white/5 transition-colors"
                  onClick={() => toggleFAQ(index)}
                  data-testid={`faq-toggle-${index}`}
                >
                  <h3 className="text-lg font-semibold" data-testid={`faq-question-${index}`}>{faq.question}</h3>
                  <ChevronDown 
                    className={`text-accent transition-transform ${openFAQ === index ? 'rotate-180' : ''}`} 
                  />
                </button>
                {openFAQ === index && (
                  <div className="px-6 pb-6 text-muted-foreground" data-testid={`faq-answer-${index}`}>
                    {faq.answer}
                  </div>
                )}
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact & Registration Section */}
      <section id="contact" className="py-20 bg-card" data-testid="contact-section">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold mb-6" data-testid="title-contact">Ready to Join?</h2>
            <p className="text-xl text-muted-foreground" data-testid="text-contact-subtitle">
              Register now and be part of the most exciting hackathon of 2025
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <img 
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Team collaboration workspace" 
                className="rounded-2xl shadow-2xl mb-8" 
                data-testid="img-team-collaboration"
              />
              
              <div className="space-y-6">
                <h3 className="text-2xl font-bold" data-testid="title-event-details">Event Details</h3>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3" data-testid="detail-university">
                    <University className="text-accent" />
                    <span>Chaudhary Ranbir Singh University, Jind, Haryana</span>
                  </div>
                  <div className="flex items-center space-x-3" data-testid="detail-date">
                    <Calendar className="text-accent" />
                    <span>October 25, 2025 (Saturday)</span>
                  </div>
                  <div className="flex items-center space-x-3" data-testid="detail-time">
                    <Clock className="text-accent" />
                    <span>9:00 AM - 7:00 PM (8 Hours)</span>
                  </div>
                  <div className="flex items-center space-x-3" data-testid="detail-email">
                    <Mail className="text-accent" />
                    <span>info@hackverse.com</span>
                  </div>
                  <div className="flex items-center space-x-3" data-testid="detail-phone">
                    <Phone className="text-accent" />
                    <span>+91 98765 43210</span>
                  </div>
                </div>
              </div>
            </div>

            <Card className="glass-card">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold mb-6" data-testid="title-registration-form">Register for HackVerse 2025</h3>
                <form onSubmit={handleFormSubmit} className="space-y-6" data-testid="form-registration">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName" className="block text-sm font-medium mb-2">First Name</Label>
                      <Input 
                        id="firstName"
                        type="text" 
                        placeholder="Enter your first name"
                        value={formData.firstName}
                        onChange={(e) => handleInputChange("firstName", e.target.value)}
                        className="bg-background border-border"
                        data-testid="input-firstName"
                      />
                    </div>
                    <div>
                      <Label htmlFor="lastName" className="block text-sm font-medium mb-2">Last Name</Label>
                      <Input 
                        id="lastName"
                        type="text" 
                        placeholder="Enter your last name"
                        value={formData.lastName}
                        onChange={(e) => handleInputChange("lastName", e.target.value)}
                        className="bg-background border-border"
                        data-testid="input-lastName"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="email" className="block text-sm font-medium mb-2">Email Address</Label>
                    <Input 
                      id="email"
                      type="email" 
                      placeholder="Enter your email"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      className="bg-background border-border"
                      data-testid="input-email"
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone" className="block text-sm font-medium mb-2">Phone Number</Label>
                    <Input 
                      id="phone"
                      type="tel" 
                      placeholder="Enter your phone number"
                      value={formData.phone}
                      onChange={(e) => handleInputChange("phone", e.target.value)}
                      className="bg-background border-border"
                      data-testid="input-phone"
                    />
                  </div>
                  <div>
                    <Label htmlFor="institution" className="block text-sm font-medium mb-2">Institution/Company</Label>
                    <Input 
                      id="institution"
                      type="text" 
                      placeholder="Enter your institution or company"
                      value={formData.institution}
                      onChange={(e) => handleInputChange("institution", e.target.value)}
                      className="bg-background border-border"
                      data-testid="input-institution"
                    />
                  </div>
                  <div>
                    <Label htmlFor="experience" className="block text-sm font-medium mb-2">Experience Level</Label>
                    <Select value={formData.experience} onValueChange={(value) => handleInputChange("experience", value)}>
                      <SelectTrigger className="bg-background border-border" data-testid="select-experience">
                        <SelectValue placeholder="Select your experience level" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="beginner">Beginner (0-1 years)</SelectItem>
                        <SelectItem value="intermediate">Intermediate (1-3 years)</SelectItem>
                        <SelectItem value="advanced">Advanced (3+ years)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="teamName" className="block text-sm font-medium mb-2">Team Name (Optional)</Label>
                    <Input 
                      id="teamName"
                      type="text" 
                      placeholder="Enter team name if participating as a team"
                      value={formData.teamName}
                      onChange={(e) => handleInputChange("teamName", e.target.value)}
                      className="bg-background border-border"
                      data-testid="input-teamName"
                    />
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full bg-accent hover:bg-accent/90 text-accent-foreground px-6 py-4 font-semibold"
                    data-testid="button-submit-registration"
                  >
                    <NotebookPen className="mr-2" />
                    Complete Registration
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-background border-t border-border py-12" data-testid="footer">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Code className="text-2xl text-accent" />
                <span className="text-xl font-bold">HackVerse</span>
              </div>
              <p className="text-muted-foreground" data-testid="text-footer-description">
                The ultimate 8-hour coding challenge bringing together the brightest minds in technology.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4" data-testid="title-quick-links">Quick Links</h4>
              <div className="space-y-2">
                <button onClick={() => scrollToSection("about")} className="block text-muted-foreground hover:text-accent transition-colors" data-testid="link-about">
                  About Event
                </button>
                <button onClick={() => scrollToSection("schedule")} className="block text-muted-foreground hover:text-accent transition-colors" data-testid="link-schedule">
                  Schedule
                </button>
                <button onClick={() => scrollToSection("faq")} className="block text-muted-foreground hover:text-accent transition-colors" data-testid="link-faq">
                  FAQ
                </button>
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-4" data-testid="title-contact-info">Contact Info</h4>
              <div className="space-y-2 text-muted-foreground">
                <p data-testid="text-footer-location">CRS University, Jind</p>
                <p data-testid="text-footer-email">info@hackverse.com</p>
                <p data-testid="text-footer-phone">+91 98765 43210</p>
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-4" data-testid="title-follow-us">Follow Us</h4>
              <div className="flex space-x-4">
                <button className="text-muted-foreground hover:text-accent transition-colors" data-testid="link-twitter">
                  <Twitter className="text-xl" />
                </button>
                <button className="text-muted-foreground hover:text-accent transition-colors" data-testid="link-instagram">
                  <Instagram className="text-xl" />
                </button>
                <button className="text-muted-foreground hover:text-accent transition-colors" data-testid="link-linkedin">
                  <Linkedin className="text-xl" />
                </button>
                <button className="text-muted-foreground hover:text-accent transition-colors" data-testid="link-github">
                  <Github className="text-xl" />
                </button>
              </div>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-muted-foreground">
            <p data-testid="text-copyright">
              &copy; 2025 HackVerse. All rights reserved. Organized by Chaudhary Ranbir Singh University, Jind.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
